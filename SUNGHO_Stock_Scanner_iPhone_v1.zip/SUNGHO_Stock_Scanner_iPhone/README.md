# SUNGHO Scanner — iPhone Web App

이 버전은 iPhone Safari에서 사용하기 좋게 모바일 화면으로 최적화한 Streamlit 웹앱입니다.

## 가장 쉬운 배포 방법: Streamlit Community Cloud
1. GitHub에 새 저장소를 만듭니다.
2. 이 폴더의 `app.py`, `requirements.txt`를 저장소에 올립니다.
3. Streamlit Community Cloud에서 해당 GitHub 저장소를 선택합니다.
4. Main file을 `app.py`로 지정하고 Deploy 합니다.
5. 생성된 HTTPS 주소를 iPhone Safari에서 엽니다.
6. Safari 공유 버튼 → `홈 화면에 추가`를 누르면 앱처럼 실행할 수 있습니다.

## 로컬 테스트
pip install -r requirements.txt
streamlit run app.py

## 현재 기능
- iPhone 모바일 UI
- KOSPI/KOSDAQ 후보 스캔
- TOP 10 카드
- 5/10/20/60일 이동평균
- 20일선 눌림/회복
- 돌파/모멘텀 탐색
- 거래량/거래대금
- RSI/MACD
- ATR 기반 손절 참고값
- 지지/저항
- CSV 저장

## 다음 버전 권장
실시간 장중 데이터, 외국인/기관 수급, VWAP, 뉴스/공시를 붙이려면 안정적인 실시간 데이터 API 또는 증권사 API가 필요합니다.
